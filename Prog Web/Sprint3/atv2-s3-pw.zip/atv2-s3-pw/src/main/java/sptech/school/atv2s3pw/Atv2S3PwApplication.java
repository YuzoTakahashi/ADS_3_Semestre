package sptech.school.atv2s3pw;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Atv2S3PwApplication {

	public static void main(String[] args) {
		SpringApplication.run(Atv2S3PwApplication.class, args);
	}

}
