package sptech.school.atv2s3pw;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Atv2S3PwApplicationTests {

	@Test
	void contextLoads() {
	}

}
